/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kantorwalut;

// hermetyzacja gettery settery
// obiekt ktory przetrzymuje dane aby mozna bylo je dodac do wygladu aplikacji
public class Currency {
    private double usd;
    private double eur;
    private double gbp;
    private double chr;
    private double jpy;
    
    public Currency(double usd, double eur, double gbp, double chr, double jpy) {
        this.usd = usd;
        this.eur = eur;
        this.gbp = gbp;
        this.chr = chr;
        this.jpy = jpy;
    }
    
    public double getUsd() {
        return usd;
    }
    
    public void setUsd(double usd) {
        this.usd = usd;
    }
    
    public double getEur() {
        return eur;
    }
    
    public void setEur(double eur) {
        this.eur = eur;
    }
    
    public double getGbp() {
        return gbp;
    }
    
    public void setGbp(double gbp) {
        this.gbp = gbp;
    }
    
    public double getChr() {
        return chr;
    }
    
    public void setChr(double chr) {
        this.chr = chr;
    }
    
    public double getJpy() {
        return jpy;
    }
    
    public void setJpy(double jpy) {
        this.jpy = jpy;
    }
}
