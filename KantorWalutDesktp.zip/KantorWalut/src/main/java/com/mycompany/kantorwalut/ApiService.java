/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kantorwalut;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;



public class ApiService {
    
    private double usd;
    private double eur;
    private double gbp;
    private double chf;
    private double jpy;
    
    // metoda zwracajaca obiekt ktory stworzylismy wczesniej
    // musi miec na koncu return new Currency(itp..) czyli w tym musi byc stworzony obiekt
    public Currency buyCurrency() {        
        try {
            // url i polaczenie z api
            URL url = new URL("https://api.nbp.pl/api/exchangerates/tables/c");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            
            // metoda zapytania czyli pobieramy dane
            conn.setRequestMethod("GET");

            // odczytywanie odpowiedzi serwera
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder xmlResponse = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                xmlResponse.append(line);
            }
            reader.close();

            // wsadzenie odpowiedzi serwera do stringa
            String xmlData = xmlResponse.toString().trim();

            // dostanie sie do odpowiedzi serwera listy wszystkich dostepnych walut
            JSONParser parser = new JSONParser();
            JSONArray response = (JSONArray) parser.parse(xmlData);
            JSONObject rates = (JSONObject) response.get(0);
            JSONArray allCurrency = (JSONArray) rates.get("rates");

            /* przeszukujemy cala liste allCurrency jesli trafimy na 
               code z nazwa waluty ktora chcemy przypisujemy to do zmiennej,
               tak to na stronie wyglada z api i code to USD
                <Rates>
                    <Rate>
                        <Currency>dolar amerykański</Currency>
                        <Code>USD</Code>
                        <Bid>4.0243</Bid>
                        <Ask>4.1057</Ask>
                    </Rate>
            */
            
            // petla forEach
            // trwa tak długo jak dluga jest lista
            for (Object currencyObj : allCurrency) {
                JSONObject currency = (JSONObject) currencyObj;
                String code = (String) currency.get("code");

                if (code.equals("USD")) {
                    usd = (Double) currency.get("bid");
                    
                }

                if(code.equals("EUR")) {
                    eur = (Double) currency.get("bid");
                }
                
                if(code.equals("GBP")) {
                    gbp = (Double) currency.get("bid");
                }
                
                if(code.equals("CHF")) {
                    chf = (Double) currency.get("bid");
                }
                
                if(code.equals("JPY")) {
                    jpy = (Double) currency.get("bid");
                }
            }
            
            // zwracamy obiekt Currency ktory przetrzyma nam wszystkie wartosci
            return new Currency(usd, eur, gbp, chf, jpy);
        } catch (Exception e) {
            // zwracanie błędu
            throw new RuntimeException(e);
        }
    }
    
    
    // to samo tylko ze sprzedazy
    public Currency sellCurrency() {
        try {
            URL url = new URL("https://api.nbp.pl/api/exchangerates/tables/c");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder xmlResponse = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                xmlResponse.append(line);
            }
            reader.close();

            String xmlData = xmlResponse.toString().trim();

            JSONParser parser = new JSONParser();
            JSONArray response = (JSONArray) parser.parse(xmlData);
            JSONObject rates = (JSONObject) response.get(0);
            JSONArray allCurrency = (JSONArray) rates.get("rates");

            for (Object currencyObj : allCurrency) {
                JSONObject currency = (JSONObject) currencyObj;
                String code = (String) currency.get("code");

                if (code.equals("USD")) {
                    usd = (Double) currency.get("ask");
                    
                }

                if(code.equals("EUR")) {
                    eur = (Double) currency.get("ask");
                }
                
                if(code.equals("GBP")) {
                    gbp = (Double) currency.get("ask");
                }
                
                if(code.equals("CHF")) {
                    chf = (Double) currency.get("ask");
                }
                
                if(code.equals("JPY")) {
                    jpy = (Double) currency.get("ask");
                }
            }
            
            return new Currency(usd, eur, gbp, chf, jpy);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
