/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.Random;

/**
 *
 * @author user
 */
public class Generowanie {
    String[] abcd = {"A","B","C","D","E","F","G","H","I","J","K","L","Ł","M","N","O","P","R","S","T","U","V","W","X","Y","Z"};
    
    public String losujDwieLitery() {
        Random r = new Random();
        String litera1 = (abcd[r.nextInt(26)]);
        String litera2 = (abcd[r.nextInt(26)]);
        int piecLiczb = r.nextInt(100000);

        return "" + litera1 + litera2 + " " + piecLiczb;
}
   
}
