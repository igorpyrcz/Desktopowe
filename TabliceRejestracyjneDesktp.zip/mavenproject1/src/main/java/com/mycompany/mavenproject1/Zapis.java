/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Zapis {
    public void Zapis(String a){
       try {
        FileWriter fw = new FileWriter("tablice.txt",true); 
        
        fw.write(a+" \n");
        
        fw.close();
    } catch (IOException ex) {
        Logger.getLogger(Tablicerejestracyjne.class.getName()).log(Level.SEVERE, null, ex); 
    }
}
}
